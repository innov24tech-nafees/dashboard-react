import React from "react";


function HomePage() {

    return (

        <>
            <div className="flex wrapper">

                {/* <!-- Menu   fixed h-screen   overflow-scroll --> */}

                {/* <!-- Sidenav Brand Logo --> */}
                <div className="app-menu scrollable fixed h-screen   overflow-scroll">
                    <a href="index.html" className="logo-box">
                        {/* <!-- Light Brand Logo --> */}
                        <div className="logo-light">
                            <img src="./img/logo-light.png" className="logo-lg lg-logo-light" alt="Light logo" />
                            <img src="./img/logo-sm (1).png" className="logo-sm  " alt="Small logo" />
                        </div>

                        {/* <!-- Dark Brand Logo --> */}
                        <div className="logo-dark">
                            <img src="./img/logo-dark.png" className="logo-lg dark:block side-menu-user" alt="Dark logo" />
                            <img src="./img/logo-sm (2).png" className="logo-sm company-logo" alt="Small logo" />
                        </div>
                    </a>



                    {/* <!--- Menu --> */}
                    <div className="">
                        {/* <!-- User Box --> */}

                        <div className="user-box relative text-center mt-5 side-menu-user">
                            <img src="./img/user-1.jpg" alt="user-image"
                                className="rounded-full h-14 w-14 p-1 border border-gray-300/30 mx-auto mb-3" />
                            <div>
                                <button data-fc-type="dropdown" data-fc-placement="bottom" type="button"
                                    className="dark:text-white user-name text-[15px] font-medium mb-1.5">Nowak Helme</button>
                                <div
                                    className=" fc-dropdown-open:opacity-100 hidden opacity-0 w-40 z-50 transition-all duration-300 bg-white shadow-lg border rounded-lg p-2 border-gray-200 dark:border-gray-700 dark:bg-gray-800">

                                    {/* <!-- item--> */}
                                    <a className="flex items-center py-2 px-3 rounded-md text-sm text-gray-800 hover:bg-primary dark:text-gray-400 hover:text-white dark:hover:text-white"
                                        href="#">
                                        <i data-lucide="user" className="w-4 h-4 me-2"></i>
                                        <h1>My Account</h1>
                                    </a>

                                    {/* <!-- item--> */}
                                    <a className="flex items-center py-2 px-3 rounded-md text-sm text-gray-800 hover:bg-primary dark:text-gray-400 hover:text-white dark:hover:text-white"
                                        href="#">
                                        <i data-lucide="settings" className="w-4 h-4 me-2"></i>
                                        <span>Settings</span>
                                    </a>

                                    {/* <!-- item--> */}
                                    <a className="flex items-center py-2 px-3 rounded-md text-sm text-gray-800 hover:bg-primary dark:text-gray-400 hover:text-white dark:hover:text-white"
                                        href="#">
                                        <i data-lucide="lock" className="w-4 h-4 me-2"></i>
                                        <span>Lock Screen</span>
                                    </a>

                                    {/* <!-- item--> */}
                                    <a className="flex items-center py-2 px-3 rounded-md text-sm text-gray-800 hover:bg-primary dark:text-gray-400 hover:text-white dark:hover:text-white"
                                        href="#">
                                        <i data-lucide="log-out" className="w-4 h-4 me-2"></i>
                                        <span>Logout</span>
                                    </a>
                                </div>
                            </div>

                            <p className="user-name text-sm mb-3">Admin Head</p>

                            <div className="flex justify-center gap-2 mb-4">
                                <a href="#" className="user-name">
                                    {/* <!-- <i className="mdi mdi-cog text-base"></i> --> */}
                                    <i className="fa-solid fa-gear"></i>
                                </a>

                                <a href="#" className="user-name">
                                    {/* <!-- <i className="mdi mdi-power text-base"></i> --> */}
                                    <i className="fa-solid fa-power-off"></i>
                                </a>
                            </div>
                        </div>

                        <ul className="menu all-menus " data-fc-type="accordion">
                            <li className="menu-title side-menu-user">Navigation</li>

                            <li className="menu-item">
                                <a href="index.html" className="menu-link">
                                    <span className="menu-icon">
                                        {/* <!-- <i className="mdi mdi-view-dashboard-outline"></i> --> */}
                                        <i className="fa-solid fa-table-columns"></i>
                                    </span>
                                    <span className="menu-text side-menu-user"> Dashboard </span>
                                </a>
                            </li>

                            <li className="menu-title side-menu-user">Apps</li>

                            <li className="menu-item">
                                <a href="calender.html" className="menu-link">
                                    <span className="menu-icon">
                                        {/* <!-- <i className="mdi mdi-calendar-blank-outline"></i> --> */}
                                        <i className="fa-regular fa-calendar"></i>
                                    </span>
                                    <span className="menu-text side-menu-user"> Calendar </span>
                                </a>
                            </li>

                            <li className="menu-item">
                                <a href="apps-chat.html" className="menu-link">
                                    <span className="menu-icon">
                                        {/* <!-- <i className="mdi mdi-forum-outline"></i> --> */}
                                        <i className="fa-regular fa-comments"></i>
                                    </span>
                                    <span className="menu-text side-menu-user"> Chat </span>
                                </a>
                            </li>

                            <ul className="menu">
                                <li className="menu-item display">
                                    <a href="javascript:void(0)" className="menu-link right-arrow">
                                        <span className="menu-icon">
                                            {/* <!-- <i className="mdi mdi-email-outline"></i> --> */}
                                            <i className="fa-regular fa-envelope"></i>
                                            <span className="menu-text side-menu-user"> Email </span>
                                        </span>
                                        <span className="menu-arrow">
                                            <i className="fa-solid fa-chevron-right right-icon side-menu-user"></i>
                                        </span>
                                        {/* <!-- <span className="menu-arrow"></span> --> */}

                                    </a>

                                    <ul className="sub-menu hidden">
                                        <li className="menu-item">
                                            <a href="email-inbox.html" className="menu-link" role="menuitem">
                                                <span className="menu-text">Inbox</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="email-templates.html" className="menu-link">
                                                <span className="menu-text">Email Templates</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>


                            <ul className="menu">
                                <li className="menu-item display">
                                    <a href="javascript:void(0)" className="menu-link  right-arrow">
                                        <span className="menu-icon">
                                            {/* <!-- <i className="mdi mdi-clipboard-outline"></i> --> */}
                                            <i className="fa-regular fa-clipboard"></i>
                                            <span className="menu-text side-menu-user"> Tasks </span>
                                        </span>
                                        <span className="menu-arrow">
                                            <i className="fa-solid fa-chevron-right right-icon side-menu-user"></i>
                                        </span>
                                        {/* <!-- <span className="menu-arrow"></span> --> */}
                                    </a>

                                    <ul className="sub-menu hidden">
                                        <li className="menu-item">
                                            <a href="task-kanban-board.html" className="menu-link">
                                                <span className="menu-text">Kanban Board</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="task-details.html" className="menu-link">
                                                <span className="menu-text">Details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>


                            <li className="menu-item">
                                <a href="apps-projects.html" className="menu-link">
                                    <span className="menu-icon">
                                        {/* <!-- <i className="mdi mdi-briefcase-variant-outline"></i> --> */}
                                        <i className="fa-solid fa-suitcase-medical"></i>
                                    </span>
                                    <span className="menu-text side-menu-user"> Projects </span>
                                </a>
                            </li>

                            <ul className="menu">
                                <li className="menu-item display">
                                    <a href="javascript:void(0)" className="menu-link right-arrow">
                                        <span className="menu-icon">
                                            {/* <!-- <i className="mdi mdi-book-open-page-variant-outline"></i> --> */}
                                            <i className="fa-solid fa-book-open"></i>

                                            <span className="menu-text side-menu-user"> Contacts </span>
                                        </span>
                                        <span className="menu-arrow">
                                            <i className="fa-solid fa-chevron-right right-icon side-menu-user"></i>
                                        </span>
                                        {/* <!-- <span className="menu-arrow"></span> --> */}
                                    </a>

                                    <ul className="sub-menu hidden">
                                        <li className="menu-item">
                                            <a href="contacts-list.html" className="menu-link">
                                                <span className="menu-text">Members List</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="contacts-profile.html" className="menu-link">
                                                <span className="menu-text">Profile</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>


                            <li className="menu-title side-menu-user">Custom</li>


                            <ul className="menu">
                                <li className="menu-item display">
                                    <a href="javascript:void(0)" className="menu-link right-arrow">
                                        <span className="menu-icon">
                                            {/* <!-- <i className="mdi mdi-account-multiple-plus-outline"></i> --> */}
                                            <i className="fa-solid fa-user-group"></i>
                                            <span className="menu-text side-menu-user"> Auth Pages </span>
                                        </span>
                                        <span className="menu-arrow">
                                            <i className="fa-solid fa-chevron-right right-icon side-menu-user"></i>
                                        </span>
                                    </a>

                                    <ul className="sub-menu hidden">
                                        <li className="menu-item">
                                            <a href="auth-login.html" className="menu-link">
                                                <span className="menu-text">Log In</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="auth-register.html" className="menu-link">
                                                <span className="menu-text">Register</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="auth-recoverpw.html" className="menu-link">
                                                <span className="menu-text">Recover Password</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="auth-lock-screen.html" className="menu-link">
                                                <span className="menu-text">Lock Screen</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="auth-confirm-mail.html" className="menu-link">
                                                <span className="menu-text">Confirm Mail</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="auth-logout.html" className="menu-link">
                                                <span className="menu-text">Logout</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>


                            <li className="menu-item">
                                <a href="javascript:void(0)" className="menu-link">
                                    <span className="menu-icon">
                                        {/* <!-- <i className="mdi mdi-file-multiple-outline"></i> --> */}
                                        <i className="fa-regular fa-copy"></i>
                                    </span>
                                    <span className="menu-text side-menu-user"> Extra Pages </span>
                                    <span className="menu-arrow"></span>
                                </a>

                                <ul className="sub-menu hidden">
                                    <li className="menu-item">
                                        <a href="pages-starter.html" className="menu-link">
                                            <span className="menu-text">Starter</span>
                                        </a>
                                    </li>
                                    <li className="menu-item">
                                        <a href="pages-pricing.html" className="menu-link">
                                            <span className="menu-text">Pricing</span>
                                        </a>
                                    </li>
                                    <li className="menu-item">
                                        <a href="pages-timeline.html" className="menu-link">
                                            <span className="menu-text">Timeline</span>
                                        </a>
                                    </li>
                                    <li className="menu-item">
                                        <a href="pages-invoice.html" className="menu-link">
                                            <span className="menu-text">Invoice</span>
                                        </a>
                                    </li>
                                    <li className="menu-item">
                                        <a href="pages-faqs.html" className="menu-link">
                                            <span className="menu-text">FAQs</span>
                                        </a>
                                    </li>
                                    <li className="menu-item">
                                        <a href="pages-gallery.html" className="menu-link">
                                            <span className="menu-text">Gallery</span>
                                        </a>
                                    </li>
                                    <li className="menu-item">
                                        <a href="pages-404.html" className="menu-link">
                                            <span className="menu-text">Error 404</span>
                                        </a>
                                    </li>
                                    <li className="menu-item">
                                        <a href="pages-500.html" className="menu-link">
                                            <span className="menu-text">Error 500</span>
                                        </a>
                                    </li>
                                    <li className="menu-item">
                                        <a href="pages-maintenance.html" className="menu-link">
                                            <span className="menu-text">Maintenance</span>
                                        </a>
                                    </li>
                                    <li className="menu-item">
                                        <a href="pages-coming-soon.html" className="menu-link">
                                            <span className="menu-text">Coming Soon</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>

                            <li className="menu-item">
                                <a href="layouts-horizontal.html" className="menu-link" target="_blank">
                                    <span className="menu-icon">

                                        {/* <!--<i className="mdi mdi-dock-window"></i> --> */}
                                        <i className="fa-solid fa-tv"></i>
                                    </span>
                                    <span className="menu-text side-menu-user"> Horizontal </span>
                                </a>
                            </li>

                            <li className="menu-title side-menu-user">Components</li>

                            <ul className="menu">
                                <li className="menu-item display">
                                    <a href="javascript:void(0)" className="menu-link right-arrow">
                                        <span className="menu-icon">
                                            {/* <!-- <i className="mdi mdi-briefcase-outline"></i> --> */}
                                            <i className="fa-solid fa-suitcase-rolling"></i>

                                            <span className="menu-text side-menu-user"> Base UI </span>
                                        </span>
                                        <span className="menu-arrow">
                                            <i className="fa-solid fa-chevron-right right-icon side-menu-user"></i>
                                        </span>
                                        {/* <!-- <span className="menu-arrow"></span> --> */}
                                    </a>

                                    <ul className="sub-menu hidden">
                                        <li className="menu-item">
                                            <a href="ui-buttons.html" className="menu-link">
                                                <span className="menu-text">Buttons</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-badges.html" className="menu-link">
                                                <span className="menu-text">Badges</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-cards.html" className="menu-link">
                                                <span className="menu-text">Cards</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-avatars.html" className="menu-link">
                                                <span className="menu-text">Avatars</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-tabs-accordions.html" className="menu-link">
                                                <span className="menu-text">Tabs & Accordions</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-modals.html" className="menu-link">
                                                <span className="menu-text">Modals</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-progress.html" className="menu-link">
                                                <span className="menu-text">Progress</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-notifications.html" className="menu-link">
                                                <span className="menu-text">Notifications</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-offcanvas.html" className="menu-link">
                                                <span className="menu-text">Offcanvas</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-placeholders.html" className="menu-link">
                                                <span className="menu-text">Placeholders</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-spinners.html" className="menu-link">
                                                <span className="menu-text">Spinners</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui.images.html" className="menu-link">
                                                <span className="menu-text">Images</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-swiper.html" className="menu-link">
                                                <span className="menu-text">Swiper</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-list-group.html" className="menu-link">
                                                <span className="menu-text">List Group</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-ratio.html" className="menu-link">
                                                <span className="menu-text">Embed Video</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-dropdowns.html" className="menu-link">
                                                <span className="menu-text">Dropdowns</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-tooltips-popovers.html" className="menu-link">
                                                <span className="menu-text">Tooltips & Popovers</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="ui-typography.html" className="menu-link">
                                                <span className="menu-text">Typography</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>

                            <li className="menu-item">
                                <a href="widgets.html" className="menu-link">
                                    <span className="menu-icon">
                                        {/* <!-- <i className="mdi mdi-gift-outline"></i> --> */}
                                        <i className="fa-solid fa-gift"></i>

                                    </span>
                                    <span className="menu-text side-menu-user"> Widgets </span>
                                </a>
                            </li>


                            <ul className="menu">
                                <li className="menu-item display">
                                    <a href="javascript:void(0)" className="menu-link right-arrow">
                                        <span className="menu-icon">
                                            {/* <!-- <i className="mdi mdi-layers-outline"></i> --> */}
                                            <i className="fa-solid fa-layer-group"></i>

                                            <span className="menu-text side-menu-user"> Extended UI </span>
                                        </span>
                                        <span className="menu-arrow">
                                            <i className="fa-solid fa-chevron-right right-icon side-menu-user"></i>
                                        </span>
                                    </a>

                                    <ul className="sub-menu hidden">
                                        <li className="menu-item">
                                            <a href="extended-range-slider.html" className="menu-link">
                                                <span className="menu-text">Range Slider</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="extended-sweet-alert.html" className="menu-link">
                                                <span className="menu-text">Sweet Alert</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="extended-draggable-cards.html" className="menu-link">
                                                <span className="menu-text">Draggable Cards</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="extended-tour.html" className="menu-link">
                                                <span className="menu-text">Tour Page</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="extended-treeview.html" className="menu-link">
                                                <span className="menu-text">Tree View</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>


                            <ul className="menu">
                                <li className="menu-item display">
                                    <a href="javascript:void(0)" className="menu-link right-arrow">
                                        <span className="menu-icon">
                                            {/* <!-- <i className="mdi mdi-shield-outline"></i> --> */}
                                            <i className="fa-solid fa-shield"></i>

                                            <span className="menu-text side-menu-user"> Icons </span>
                                        </span>
                                        <span className="menu-arrow">
                                            <i className="fa-solid fa-chevron-right right-icon side-menu-user"></i>
                                        </span>
                                    </a>

                                    <ul className="sub-menu hidden">
                                        <li className="menu-item">
                                            <a href="icons-material-design.html" className="menu-link">
                                                <span className="menu-text">Material Design</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="icons-material-symbols.html" className="menu-link">
                                                <span className="menu-text">Material Symbols</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="icons-lucide.html" className="menu-link">
                                                <span className="menu-text">Lucide Icons</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="icons-font-awesome.html" className="menu-link">
                                                <span className="menu-text">Font Awesome 5</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>


                            <ul className="menu">
                                <li className="menu-item display">
                                    <a href="javascript:void(0)" className="menu-link  right-arrow">
                                        <span className="menu-icon">
                                            {/* <!-- <i className="mdi mdi-texture"></i> --> */}
                                            <i className="fa-light fa-grip-lines"></i>

                                            <span className="menu-text side-menu-user"> Forms </span>
                                        </span>
                                        <span className="menu-arrow">
                                            <i className="fa-solid fa-chevron-right right-icon side-menu-user"></i>
                                        </span>
                                    </a>

                                    <ul className="sub-menu hidden">
                                        <li className="menu-item">
                                            <a href="forms-elements.html" className="menu-link">
                                                <span className="menu-text">General Elements</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="forms-advanced.html" className="menu-link">
                                                <span className="menu-text">Advanced</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="forms-validation.html" className="menu-link">
                                                <span className="menu-text">Validation</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="forms-wizard.html" className="menu-link">
                                                <span className="menu-text">Wizard</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="forms-quilljs-editor.html" className="menu-link">
                                                <span className="menu-text">Quilljs Editor</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="forms-picker.html" className="menu-link">
                                                <span className="menu-text">Picker</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="forms-file-uploads.html" className="menu-link">
                                                <span className="menu-text">File Uploads</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>

                            <ul className="menu">
                                <li className="menu-item display">
                                    <a href="javascript:void(0)" className="menu-link right-arrow">
                                        <span className="menu-icon">
                                            {/* <!-- <i className="mdi mdi-table"></i> --> */}
                                            <i className="fa-solid fa-table"></i>

                                            <span className="menu-text side-menu-user"> Tables </span>
                                        </span>
                                        <span className="menu-arrow">
                                            <i className="fa-solid fa-chevron-right right-icon side-menu-user"></i>
                                        </span>
                                    </a>

                                    <ul className="sub-menu hidden">
                                        <li className="menu-item">
                                            <a href="tables-basic.html" className="menu-link">
                                                <span className="menu-text">Basic Tables</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="tables-datatables.html" className="menu-link">
                                                <span className="menu-text">Data Tables</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="tables-editable.html" className="menu-link">
                                                <span className="menu-text">Editable Tables</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="tables-tablesaw.html" className="menu-link">
                                                <span className="menu-text">Tablesaw Tables</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>

                            <ul className="menu">
                                <li className="menu-item display">
                                    <a href="javascript:void(0)" className="menu-link right-arrow">
                                        <span className="menu-icon">
                                            {/* <!-- <i className="mdi mdi-equalizer"></i> --> */}
                                            <i className="fa-solid fa-chart-simple"></i>

                                            <span className="menu-text side-menu-user"> Apex Charts </span>
                                        </span>
                                        <span className="menu-arrow">
                                            <i className="fa-solid fa-chevron-right right-icon side-menu-user"></i>
                                        </span>
                                    </a>

                                    <ul className="sub-menu hidden">
                                        <li className="menu-item">
                                            <a href="charts-apex-area.html" className="menu-link">
                                                <span className="menu-text">Area</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-bar.html" className="menu-link">
                                                <span className="menu-text">Bar</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-bubble.html" className="menu-link">
                                                <span className="menu-text">Bubble</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-candlestick.html" className="menu-link">
                                                <span className="menu-text">Candlestick</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-column.html" className="menu-link">
                                                <span className="menu-text">Column</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-heatmap.html" className="menu-link">
                                                <span className="menu-text">Heatmap</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-line.html" className="menu-link">
                                                <span className="menu-text">Line</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-mixed.html" className="menu-link">
                                                <span className="menu-text">Mixed</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-timeline.html" className="menu-link">
                                                <span className="menu-text">Timeline</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-boxplot.html" className="menu-link">
                                                <span className="menu-text">Boxplot</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-treemap.html" className="menu-link">
                                                <span className="menu-text">Treemap</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-pie.html" className="menu-link">
                                                <span className="menu-text">Pie</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-radar.html" className="menu-link">
                                                <span className="menu-text">Radar</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-radialbar.html" className="menu-link">
                                                <span className="menu-text">Radialbar</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-scatter.html" className="menu-link">
                                                <span className="menu-text">Scatter</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-polar-area.html" className="menu-link">
                                                <span className="menu-text">Polar Area</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-apex-sparklines.html" className="menu-link">
                                                <span className="menu-text">Sparklines</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>

                            <ul className="menu">
                                <li className="menu-item display">
                                    <a href="javascript:void(0)" className="menu-link right-arrow">
                                        <span className="menu-icon">
                                            {/* <!-- <i className="mdi mdi-chart-donut-variant"></i> --> */}
                                            <i className="fa-solid fa-chart-pie"></i>

                                            <span className="menu-text side-menu-user"> Chartsjs </span>
                                        </span>
                                        <span className="menu-arrow">
                                            <i className="fa-solid fa-chevron-right right-icon side-menu-user"></i>
                                        </span>
                                    </a>

                                    <ul className="sub-menu hidden">
                                        <li className="menu-item">
                                            <a href="charts-chartjs-area.html" className="menu-link">
                                                <span className="menu-text">Area</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-chartjs-bar.html" className="menu-link">
                                                <span className="menu-text">Bar</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-chartjs-line.html" className="menu-link">
                                                <span className="menu-text">Line</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="charts-chartjs-other.html" className="menu-link">
                                                <span className="menu-text">Other</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>

                            <ul className="menu">
                                <li className="menu-item display">
                                    <a href="javascript:void(0)" className="menu-link right-arrow">
                                        <span className="menu-icon">
                                            {/* <!-- <i className="mdi mdi-map"></i> --> */}
                                            <i className="fa-solid fa-map"></i>

                                            <span className="menu-text side-menu-user"> Maps </span>
                                        </span>
                                        <span className="menu-arrow">
                                            <i className="fa-solid fa-chevron-right right-icon side-menu-user"></i>
                                        </span>
                                    </a>

                                    <ul className="sub-menu hidden">
                                        <li className="menu-item">
                                            <a href="maps-google.html" className="menu-link">
                                                <span className="menu-text">Google Maps</span>
                                            </a>
                                        </li>
                                        <li className="menu-item">
                                            <a href="maps-vector.html" className="menu-link">
                                                <span className="menu-text">Vector Maps</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </ul>
                    </div>
                </div>






                {/* <!-- Sidenav Menu End  --> */}


                {/* <!-- ============================================================== --> */}
                {/* <!-- Start Page Content here --> */}
                {/* <!-- ============================================================== --> */}
                <div className="page-content-all-area">
                    <div className="page-content   ">

                        {/* <!-- Topbar Start --> */}
                        <div className="app-header" >
                            <div className="flex gap-3 items-center py-8 px-6 header-nav  ">
                                {/* <!--  Brand Logo  --> */}
                                <a href="index.html" className="logo-box">
                                    {/* <!--  Light Brand Logo  --> */}
                                    {/* <!-- <div className="logo-light">
                    <img src="assets/images/logo-light.png" className="logo-lg" alt="Light logo">
                    <img src="assets/images/logo-sm.png" className="logo-sm" alt="Small logo">
                </div> --> */}

                                    {/* <!--  Dark Brand Logo  --> */}
                                    {/* <!-- <div className="logo-dark">
                    <img src="assets/images/logo-dark.png" className="logo-lg" alt="Dark logo">
                    <img src="assets/images/logo-sm.png" className="logo-sm" alt="Small logo">
                </div> --> */}
                                </a>

                                {/* <!-- Sidenav Menu Toggle Button  --> */}
                                <button id="button-toggle-menu" className="nav-link p-2">
                                    <span className="sr-only">Menu Toggle Button</span>
                                    <span className="flex items-center justify-center h-6 w-6 toggle-icon">
                                        <i className="fa-solid fa-bars"></i>
                                        {/* <!-- <i data-lucide="menu" className="w-6 h-6 text-xl"></i> --> */}
                                    </span>
                                </button>

                                {/* <!-- Page Title  --> */}
                                <div className="me-auto">
                                    <div className="md:flex hidden">
                                        <h4 className="page-title text-lg font-bold">Dashboard</h4>
                                    </div>
                                </div>

                                <div className="md:flex hidden items-center relative">
                                    <div
                                        className="absolute inset-y-0 end-0 flex items-center pe-3 pointer-events-none toggle-icon">
                                        {/* <!-- <i className="mdi mdi-magnify text-base opacity-60 -z-10"></i> --> */}
                                        <i className="text-xs fa-solid fa-magnifying-glass"></i>
                                    </div>
                                    <input type="search"
                                        className="form-input pe-8 ps-4 py-1.5 rounded-full bg-gray-500/10 border focus:border-transparent placeholder:opacity-60"
                                        placeholder="Search..." />
                                </div>

                                {/* <!--  Light/Dark Toggle Button --> */}
                                <div className="flex">
                                    <button id="dark-mode-toggle" type="button" className="nav-link p-2">
                                        <span className="sr-only">Light/Dark Mode</span>
                                        <span className="flex items-center justify-center h-6 w-6 toggle-icon">

                                            <i className="fa-regular fa-moon dark:hidden hover:text-[#71b6f9]"></i>
                                            <i className="fa-regular fa-sun hidden dark:block "></i>
                                            {/* <!-- <i data-lucide="sun" className="hidden dark:block"></i> --> */}
                                        </span>
                                    </button>
                                </div>

                                {/* <!-- Notification Bell Button  --> */}

                                <div className="relative md:flex hidden notification">
                                    <button data-fc-type="dropdown" data-fc-placement="bottom-end" type="button"
                                        className="nav-link p-2">
                                        <span className="sr-only">View notifications</span>
                                        <span className="flex items-center justify-center h-6 w-6 toggle-icon" id="bell-icon">
                                            {/* <!-- <i data-lucide="bell"></i> --> */}
                                            <i className="fa-regular fa-bell hover:text-[#71b6f9]"></i>
                                            <span
                                                className="absolute  end-1.5 w-4 h-4 flex items-center justify-center rounded-full bg-[#ff0000c2] top-0 text-white  font-medium text-[10px]">9</span>
                                        </span>
                                    </button>


                                    <div
                                        className="total-revenue notification-massage absolute left-[-18rem] bg-white   top-[3rem] fc-dropdown  fc-dropdown-open:opacity-100 hidden  w-80 z-50 transition-[margin,opacity] duration-300   dark:bg-black shadow-lg border border-gray-200 dark:border-gray-700 rounded-lg">

                                        <div className="p-4">

                                            <div className="flex items-center justify-between">
                                                <h6 className="text-sm"> Notification</h6>
                                                <a href="javascript: void(0);" className="text-gray-500">
                                                    <small id="clear-all-link" className="card-title">Clear All</small>
                                                </a>
                                            </div>
                                        </div>

                                        <div className="p-4 h-80" data-simplebar>
                                            <h5 className="text-xs text-gray-500 dark:text-gray-300 mb-2">Today</h5>

                                            <a href="javascript:void(0);" className="block mb-4">
                                                <div className="card-body">
                                                    <div className="flex items-center">
                                                        <div className="flex-shrink-0">
                                                            <div
                                                                className="flex justify-center items-center h-9 w-9 rounded-full bg text-white bg-primary">
                                                                <i className="mdi mdi-comment-account-outline text-lg"></i>
                                                                <img className="rounded-full"
                                                                    src="./img/360_F_328113542_31B2IVU37qZ09cXXA6iMSXs62Optrwok.jpg"
                                                                    alt="" />
                                                            </div>
                                                        </div>
                                                        <div className="flex-grow truncate ms-2">
                                                            <h5 className="text-sm font-semibold  mb-1">Datacorp <small
                                                                className="font-normal text-gray-500 ms-1">1 min ago</small>
                                                            </h5>
                                                            <small className="noti-item-subtitle text-muted">Caleb Flakelar
                                                                commented on
                                                                Admin</small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                            <a href="javascript:void(0);" className="block mb-4">
                                                <div className="card-body">
                                                    <div className="flex items-center">
                                                        <div className="flex-shrink-0">
                                                            <div
                                                                className="flex justify-center items-center h-9 w-9 rounded-full bg-info text-white">
                                                                <i className="mdi mdi-heart text-lg"></i>
                                                                <img className="rounded-full" src="./img/user-3.jpg" alt="" />
                                                            </div>
                                                        </div>
                                                        <div className="flex-grow truncate ms-2">
                                                            <h5 className="text-sm font-semibold mb-1">Admin <small
                                                                className="font-normal text-gray-500 ms-1">1 hr ago</small></h5>
                                                            <small className="noti-item-subtitle text-muted">New user
                                                                registered</small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                            <a href="javascript:void(0);" className="block mb-4">
                                                <div className="card-body">
                                                    <div className="flex items-center">
                                                        <div className="flex-shrink-0">
                                                            <img src="./img/user-11.jpg" className="rounded-full h-9 w-9" alt="" />
                                                        </div>
                                                        <div className="flex-grow truncate ms-2">
                                                            <h5 className="text-sm font-semibold mb-1">Cristina Pride <small
                                                                className="font-normal text-gray-500 ms-1">1 day ago</small>
                                                            </h5>
                                                            <small className="noti-item-subtitle text-muted">Hi, How are you? What
                                                                about
                                                                our next meeting</small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                            <h5 className="text-xs text-gray-500 mb-2">Yesterday</h5>

                                            <a href="javascript:void(0);" className="block mb-4">
                                                <div className="card-body">
                                                    <div className="flex items-center">
                                                        <div className="flex-shrink-0">
                                                            <div
                                                                className="flex justifyer items-center h-9 w-9 rounded-full bg-primary text-white">
                                                                <i className="mdi mdi-account-plus text-lg"></i>
                                                                <img className="rounded-full" src="./img/user-2.jpg" alt="" />
                                                            </div>
                                                        </div>
                                                        <div className="flex-grow truncate ms-2">
                                                            <h5 className="text-sm font-semibold mb-1">Datacorp</h5>
                                                            <small className="noti-item-subtitle text-muted">Caleb Flakelar
                                                                commented on
                                                                Admin</small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                            <a href="javascript:void(0);" className="block">
                                                <div className="card-body">
                                                    <div className="flex items-center">
                                                        {/* <!-- <div className="flex-shrink-0">
                                        <img src="../img/user-1.jpg" className="rounded-full h-9 w-9"
                                            alt="user-logo">
                                    </div> --> */}
                                                        {/* <!-- <div className="flex-grow truncate ms-2">
                                        <h5 className="text-sm font-semibold mb-1">Karen Robinson</h5>
                                        <small className="noti-item-subtitle text-muted">Wow ! this admin looks good
                                            and awesome design</small>
                                    </div> --> */}
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="javascript:void(0);" className="block">
                                                <div className="card-body">
                                                    <div className="flex items-center">
                                                        {/* <!-- <div className="flex-shrink-0">
                                        <img src="../img/user-1.jpg" className="rounded-full h-9 w-9"
                                            alt="user-logo">
                                    </div> --> */}
                                                        {/* <!-- <div className="flex-grow truncate ms-2">
                                        <h5 className="text-sm font-semibold mb-1">Karen Robinson</h5>
                                        <small className="noti-item-subtitle text-muted">Wow ! this admin looks good
                                            and awesome design</small>
                                    </div> --> */}
                                                    </div>
                                                </div>
                                                {/* </div> */}
                                            </a>
                                        </div>



                                        <a href="javascript:void(0);"
                                            className="p-2 border-t border-dashed border-gray-200 dark:border-gray-700 block text-center text-primary underline font-semibold">
                                            View All
                                        </a>

                                    </div>
                                </div>
                                {/* <!-- </li>
            </ul> --> */}

                                {/* <!-- Profile Dropdown Button  --> */}
                                <div className="relative">
                                    <button data-fc-type="dropdown" data-fc-placement="bottom-end" type="button"
                                        id="user-profile" className="nav-link flex items-center">
                                        <img src="./img/user-11.jpg" alt="user-image" className="rounded-full h-8 w-8" />
                                        <span className="text-sm mx-2 toggle-icon hover:text-[#71b6f9]">Nowak</span>
                                        {/* <!-- <i className="mdi mdi-chevron-down"></i> --> */}
                                        <i className="text-xs fa-solid fa-angle-down toggle-icon hover:text-[#71b6f9]"></i>
                                    </button>
                                    <div
                                        className="total-revenue user-profile-id bg-white absolute fc-dropdown fc-dropdown-open:opacity-100 hidden  w-44 z-50 transition-[margin,opacity] duration-300  shadow-lg border rounded py-2 border-gray-200 dark:border-gray-700 dark:bg-black">
                                        <h6 className="py-2 px-5">Welcome !</h6>

                                        <a className="hover:text-black gap-1 flex items-center py-2 px-5 text-sm hover:bg-gray-100"
                                            href="pages-gallery.html">
                                            <i data-lucide="user" className="w-4 h-4 me-2"></i>
                                            <img className="w-3" src="./img/user.png" alt="user-logo" />
                                            <span>My Account</span>
                                        </a>


                                        <a className="flex items-center gap-1 py-2 px-5 text-sm  hover:text-black hover:bg-gray-100  dark:hover:text-black"
                                            href="apps-kanban.html">
                                            <i data-lucide="lock" className="w-4 h-4 me-2"></i>
                                            <img className="w-3" src="./img/settings.png" alt="user-logo" />
                                            <span>Settings</span>
                                        </a>
                                        <a className="flex items-center gap-1 py-2 px-5 text-sm  hover:text-black hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                            href="auth-login.html">
                                            <i data-lucide="lock" className="w-4 h-4 me-2"></i>
                                            <img className="w-3" src="./img/lock.png" alt="user-logo" />
                                            <span>Lock Screen</span>
                                        </a>
                                        <hr className="my-2 -mx-2 border-gray-200 dark:border-gray-700" />
                                        <a className="flex items-center py-2 gap-1 px-5 text-sm hover:text-black  hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                            href="auth-login.html">
                                            <i data-lucide="log-out" className="w-4 h-4 me-2"></i>
                                            <img className="w-3" src="./img/logout.png" alt="user-logo" />
                                            <span>Logout</span>
                                        </a>
                                    </div>
                                </div>

                                {/* <!-- Customization Button   --> */}
                                <div className="flex">
                                    <button type="button" className="nav-link p-2" data-fc-type="offcanvas"
                                        data-fc-target="theme-customization" data-fc-scroll="true">
                                        <span className="sr-only">Customization Button</span>
                                        <span className="flex items-center justify-center h-6 w-6 toggle-icon hover:text-[#71b6f9]">
                                            <i className="fa-solid fa-gear dark:hidden"></i>
                                            {/* <!-- <i data-lucide="settings"></i> --> */}
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>

                        {/* <!--Topbar End  --> */}


                        {/* <!-- Main Content Total Revenue card start  --> */}

                        <section className="text-gray-600  app-header">
                            <div className="container px-7 py-2 mx-auto ">
                                <div className="flex flex-wrap -m-4">
                                    <div className="lg:w-1/4 md:w-1/2 p-3 w-full">
                                        <a className="block relative rounded overflow-hidden">
                                            {/* <!-- <img alt="ecommerce" className="object-cover object-center w-full h-full block" src="https://dummyimage.com/420x260"> --> */}

                                            <div className="p-6 bg-white h-44 total-revenue rounded">
                                                <div className="flex items-center justify-between ">
                                                    <h4 className="card-title">Total Revenue</h4>

                                                    <div className="z-10">
                                                        <button className="dropdown-revenue-cl " type="button">
                                                            {/* <!-- <i className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                            <i className="fa-solid fa-ellipsis-vertical"></i>
                                                        </button>

                                                        <div id="dropdown-revenue"
                                                            className="hidden fc-dropdown bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                                href="javascript:void(0)">
                                                                Action
                                                            </a>
                                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                                href="javascript:void(0)">
                                                                Another action
                                                            </a>
                                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                                href="javascript:void(0)">
                                                                Something else
                                                            </a>
                                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                                href="javascript:void(0)">
                                                                Separated link
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="flex items-center justify-between">
                                                    <div dir="ltr" className="card">
                                                        <div className="percent">
                                                            <svg>
                                                                <circle cx="105" cy="105" r="30"></circle>
                                                                <circle cx="105" cy="105" r="30" style="--percent: 15"></circle>
                                                            </svg>
                                                            <div className="number">
                                                                <h3>58<span>%</span></h3>
                                                            </div>
                                                        </div>

                                                        <div className="text-end progress-text">
                                                            <h2
                                                                className="total-revenue revenue-nub text-3xl font-normal text-gray-800 dark:text-white mb-1">
                                                                256
                                                            </h2>
                                                            <p className="text-gray-400 font-normal">Revenue today</p>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </a>
                                    </div>


                                    <div className="lg:w-1/4 md:w-1/2 p-3 w-full">
                                        <a className="block relative rounded overflow-hidden">
                                            <div className="p-6 bg-white h-44 total-revenue rounded">
                                                <div className="flex items-center justify-between pb-6">
                                                    <h4 className="card-title">Sales Analytics</h4>

                                                    <div className="z-10">
                                                        <button className="dropdown-revenue-cl " type="button">
                                                            {/* <!-- <i className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                            <i className="fa-solid fa-ellipsis-vertical"></i>
                                                        </button>

                                                        <div id="dropdown-target1"
                                                            className="hidden bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                                href="javascript:void(0)">
                                                                Action
                                                            </a>
                                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                                href="javascript:void(0)">
                                                                Another action
                                                            </a>
                                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                                href="javascript:void(0)">
                                                                Something else
                                                            </a>
                                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                                href="javascript:void(0)">
                                                                Separated link
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="flex items-center justify-between ">
                                                <div dir="ltr" className="card w-full h-2">
                                                    <div className="flex justify-around gap-x-6 pb-2">

                                                        <div
                                                            className="bg-green-500 m-auto h-5 w-16 text-white rounded-full text-xs px-2 py-0.5">
                                                            32%
                                                            {/* <!-- <i className="mdi mdi-trending-up"></i> --> */}
                                                            <i className="fa-solid fa-arrow-trend-up"></i>
                                                        </div>
                                                        <div className="text-end ">
                                                            <h2
                                                                className="total-revenue revenue-nub text-3xl font-normal text-gray-800 dark:text-white mb-1">
                                                                4569
                                                            </h2>
                                                            <p className="text-gray-400 font-normal">Revenue today</p>
                                                        </div>
                                                    </div>
                                                    <div
                                                        className="w-full bg-gray-200 rounded-full h-2.5 mb-4 dark:bg-gray-700">
                                                        <div className="bg-green-500 h-2.5 rounded-full" style="width: 75%">
                                                        </div>
                                                    </div>


                                                </div>
                                            </div>

                                        </a>
                                    </div>
                                </div>
                            </div>

                            <div className="lg:w-1/4 md:w-1/2 p-3 w-full">
                                <a className="block relative rounded overflow-hidden">
                                    {/* <!-- <img alt="ecommerce" className="object-cover object-center w-full h-full block" src="https://dummyimage.com/420x260"> --> */}

                                    <div className="p-6 bg-white h-44 total-revenue rounded">
                                        <div className="flex items-center justify-between ">
                                            <h4 className="card-title">Statistics</h4>

                                            <div className="z-10">
                                                <button className="dropdown-revenue-cl " type="button">
                                                    {/* <!-- <i className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                    <i className="fa-solid fa-ellipsis-vertical"></i>
                                                </button>

                                                <div id="dropdown-target1"
                                                    className="hidden bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                    <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                        href="javascript:void(0)">
                                                        Action
                                                    </a>
                                                    <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                        href="javascript:void(0)">
                                                        Another action
                                                    </a>
                                                    <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                        href="javascript:void(0)">
                                                        Something else
                                                    </a>
                                                    <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                        href="javascript:void(0)">
                                                        Separated link
                                                    </a>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <div dir="ltr" className="card">
                                                <div className="percent">
                                                    <svg>
                                                        <circle cx="105" cy="105" r="30"></circle>
                                                        <circle cx="105" cy="105" r="30" style="--percent: 22"></circle>
                                                    </svg>
                                                    <div className="number">
                                                        <h3>80<span>%</span></h3>
                                                    </div>
                                                </div>

                                                <div className="text-end progress-text">
                                                    <h2
                                                        className="total-revenue revenue-nub text-3xl font-normal text-gray-800 dark:text-white mb-1">
                                                        4569
                                                    </h2>
                                                    <p className="text-gray-400 font-normal">Revenue today</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>

                            </div>



                            <div className="lg:w-1/4 md:w-1/2 p-3 w-full">
                                <a className="block relative rounded overflow-hidden">
                                    <a className="p-3 bg-white h-44 total-revenue rounded">
                                        <div className="flex items-center justify-between pb-6">
                                            <h4 className="card-title">Daily Sales</h4>

                                            <div className="z-10">
                                                <button dclassName="dropdown-revenue-cl " type="button">
                                                    {/* <!-- <i className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                    <i className="fa-solid fa-ellipsis-vertical"></i>
                                                </button>

                                                <div id="dropdown-target1"
                                                    className="hidden bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                    <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                        href="javascript:void(0)">
                                                        Action
                                                    </a>
                                                    <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                        href="javascript:void(0)">
                                                        Another action
                                                    </a>
                                                    <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                        href="javascript:void(0)">
                                                        Something else
                                                    </a>
                                                    <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                        href="javascript:void(0)">
                                                        Separated link
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </a>
                            </div>

                            <div className="flex items-center justify-between ">
                                <div dir="ltr" className="card w-full h-2">
                                    <div className="flex justify-around gap-x-6 pb-2">

                                        <div
                                            className="bg-[#ff8acc] m-auto h-5 w-16 text-white rounded-full text-xs px-2 py-0.5">
                                            32%
                                            {/* <!-- <i className="mdi mdi-trending-up"></i> --> */}
                                            <i className="fa-solid fa-arrow-trend-up"></i>
                                        </div>
                                        <div className="text-end ">
                                            <h2
                                                className="total-revenue revenue-nub text-3xl font-normal text-gray-800 dark:text-white mb-1">
                                                159
                                            </h2>
                                            <p className="text-gray-400 font-normal">Revenue today</p>
                                        </div>
                                    </div>
                                    <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4 dark:bg-gray-700">
                                        <div className="bg-[#ff8acc] h-2.5 rounded-full" style="width: 75%">
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </section>
                        {/* </a> */}

                    </div>

                </div>




                {/* <!-- deshboard chart area start --> */}
                {/* <!-- morris donut chart --> */}
                <section>

                    <div className="flex flex-wrap  w-full bg-[#f3f4f6]  app-header px-[0.8rem] py-2">
                        <div className="p-3 md:w-1/3 h-[450px]">
                            <div className="flex rounded-lg h-full bg-white p-6 flex-col total-revenue">
                                <div className="morris-area flex justify-between">
                                    <div className="morris-txt">
                                        <span>Daily Sales</span>

                                    </div>
                                    <div className="morris-icon">
                                        <div className="z-10">
                                            <button data-fc-target="dropdown-target1" data-fc-type="dropdown"
                                                type="button" data-fc-placement="bottom-end" className="fc-dropdown">
                                                {/* <!-- <i className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </button>

                                            <div id="dropdown-target1"
                                                className="hidden bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                    href="javascript:void(0)">
                                                    Action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Another action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Something else
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Separated link
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                {/* <!-- <div className="flex items-center mb-3"> --> */}

                                <div className="morris-donut relative top-[-25px]">
                                    <div id="donut-example" className="morris-donut-inverse"></div>
                                </div>





                                <div className="serieses text-center relative top-[-40px]">
                                    <div className="series-a">
                                        <span className="color-pink"></span>
                                        <span className="text-[#ff8acc]">Series A</span>
                                    </div>
                                    <div className="series-a">
                                        <span className="color-blue"></span>
                                        <span className="text-[#35b8e0]">Series B</span>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div className="p-3 md:w-1/3 h-[450px]">
                            <div className="flex rounded-lg h-full bg-white p-6 flex-col total-revenue">
                                {/* <!-- <div className="flex items-center mb-3"> --> */}


                                <div className="morris-area flex justify-between">
                                    <div className="morris-txt">
                                        <span>Daily Sales</span>

                                    </div>
                                    <div className="morris-icon">
                                        <div className="z-10">
                                            <button data-fc-target="dropdown-target1" data-fc-type="dropdown"
                                                type="button" data-fc-placement="bottom-end" className="fc-dropdown mories">
                                                {/* <!-- <i className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </button>

                                            <div id="dropdown-target1"
                                                className="hidden bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                    href="javascript:void(0)">
                                                    Action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Another action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Something else
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Separated link
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <canvas id="myChart" aria-label="chart" role="img" width="100" height="100">
                                    </canvas>
                                </div>




                                {/* <!-- </div> --> */}

                            </div>
                        </div>



                        <div className="p-3 md:w-1/3 h-[450px]">
                            <div className="flex rounded-lg h-full bg-white p-6 flex-col total-revenue">
                                {/* <!-- <div className="flex items-center mb-3"> --> */}


                                <div className="morris-area flex justify-between">
                                    <div className="morris-txt">
                                        <span>Daily Sales</span>

                                    </div>
                                    <div className="morris-icon">
                                        <div className="z-10">
                                            <button data-fc-target="dropdown-target1" data-fc-type="dropdown"
                                                type="button" data-fc-placement="bottom-end"
                                                className="fc-dropdown ">
                                                {/* <!-- <i className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </button>

                                            <div id="dropdown-target1"
                                                className="hidden bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                    href="javascript:void(0)">
                                                    Action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Another action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Something else
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Separated link
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    {/* <!-- </div> --> */}
                                </div>

                                <div>
                                    <canvas id="lineChart" aria-label="chart" role="img" width="100" height="100">
                                    </canvas>
                                </div>
                            </div>


                        </div>
                    </div>

                </section>
                {/* <!-- </div> --> */}



                {/* <!-- maim content end --> */}


                {/* <!-- identity users card start --> */}


                <section className="text-gray-600 ">
                    <div className="p-4  mx-auto bg-[#f3f4f6] app-header px-7 py-2 ">
                        <div className="flex flex-wrap -m-4 text-center">
                            <div className="p-3 md:w-1/4 sm:w-1/2 w-full">
                                <div
                                    className="total-revenue py-8 px-8 max-w-sm mx-auto bg-white rounded shadow-lg space-y-2 sm:py-4 sm:flex sm:items-center sm:space-y-0 sm:space-x-6">
                                    <img className="block mx-auto w-1/3 rounded-full sm:mx-0 sm:shrink-0"
                                        src="./img/user-1.jpg" alt="Woman's Face" />
                                    <div className="text-center space-y-2 sm:text-left">
                                        <div className="space-y-0.5">
                                            <h5 className="text-gray-800 dark:text-white mb-1 total-revenue">
                                                Chadengle
                                            </h5>
                                            <p className="mb-2 text-gray-400 font-normal truncate">
                                                coderthemes@g
                                            </p>
                                        </div>
                                        <span
                                            className="px-4 py-1 text-sm text-yellow-600 font-semibold    focus:outline-none focus:ring-2 focus:ring-purple-600 focus:ring-offset-2">Admin</span>
                                    </div>
                                </div>
                            </div>
                            <div className="p-3 md:w-1/4 sm:w-1/2 w-full">
                                <div
                                    className="total-revenue py-8 px-8 max-w-sm mx-auto bg-white rounded shadow-lg space-y-2 sm:py-4 sm:flex sm:items-center sm:space-y-0 sm:space-x-6">
                                    <img className="block  mx-auto w-1/3 rounded-full sm:mx-0 sm:shrink-0"
                                        src="./img/user-2.jpg" alt="Woman's Face" />
                                    <div className="text-center space-y-2 sm:text-left">
                                        <div className="space-y-0.5">
                                            <h5 className="text-gray-800 dark:text-white mb-1 total-revenue">
                                                Chadengle
                                            </h5>
                                            <p className="mb-2 text-gray-400 font-normal truncate">
                                                coderthemes@g
                                            </p>
                                        </div>
                                        <span
                                            className="px-4 py-1 text-sm text-pink-500 font-semibold    focus:outline-none focus:ring-2 focus:ring-purple-600 focus:ring-offset-2">Admin</span>
                                    </div>
                                </div>
                            </div>



                            <div className="p-3 md:w-1/4 sm:w-1/2 w-full">
                                <div
                                    className="total-revenue py-8 px-8 max-w-sm mx-auto bg-white rounded shadow-lg space-y-2 sm:py-4 sm:flex sm:items-center sm:space-y-0 sm:space-x-6">
                                    <img className="block mx-auto w-1/3 rounded-full sm:mx-0 sm:shrink-0"
                                        src="./img/user-3.jpg" alt="Woman's Face" />
                                    <div className="text-center space-y-2 sm:text-left">
                                        <div className="space-y-0.5">
                                            <h5 className="text-gray-800 dark:text-white mb-1 total-revenue">
                                                Chadengle
                                            </h5>
                                            <p className="mb-2 text-gray-400 font-normal truncate">
                                                Developer
                                            </p>
                                        </div>
                                        <span
                                            className="px-4 py-1 text-sm text-green-500 font-semibold    focus:outline-none focus:ring-2 focus:ring-purple-600 focus:ring-offset-2">Admin</span>
                                    </div>
                                </div>
                            </div>



                            <div className="p-3 md:w-1/4 sm:w-1/2 w-full">
                                <div
                                    className="total-revenue py-8 px-8 max-w-sm mx-auto bg-white rounded shadow-lg space-y-2 sm:py-4 sm:flex sm:items-center sm:space-y-0 sm:space-x-6">
                                    <img className="block mx-auto w-1/3 rounded-full sm:mx-0 sm:shrink-0"
                                        src="./img/user-1.jpg" alt="Woman's Face" />
                                    <div className="text-center space-y-2 sm:text-left">
                                        <div className="space-y-0.5">
                                            <h5 className="text-gray-800 dark:text-white mb-1 total-revenue">
                                                Chadengle


                                            </h5>
                                            <p className="mb-2 text-gray-400 font-normal truncate">
                                                coderthemes@g
                                            </p>
                                        </div>
                                        <span
                                            className="px-4 py-1 text-sm text-blue-400 font-semibold    focus:outline-none focus:ring-2 focus:ring-purple-600 focus:ring-offset-2">Developer</span>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>

                {/* <!-- identity card end --> */}

                {/* <!-- seshboard inbox start--> */}
                <section>
                    <div className="p-4 xl:grid-cols-3 grid-cols-1 gap-6 flex bg-[#f3f4f6] app-header px-[1.5rem] py-4">
                        <div className="card">
                            <div className="p-6 bg-white total-revenue rounded">

                                <div className="flex items-center justify-between mb-6">
                                    <h4 className="card-title">Inbox</h4>

                                    <div>
                                        <button data-fc-target="dropdown-target5" data-fc-type="dropdown" type="button"
                                            data-fc-placement="bottom-end" className="fc-dropdown">
                                            <i className="fa-solid fa-ellipsis-vertical"></i>
                                        </button>

                                        <div id=" dropdown-target5"
                                            className="bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown absolute hidden"
                                            style="left: 439.5px; top: 921px;">
                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                href="javascript:void(0)">
                                                Action
                                            </a>
                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                href="javascript:void(0)">
                                                Another action
                                            </a>
                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                href="javascript:void(0)">
                                                Something else
                                            </a>
                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                href="javascript:void(0)">
                                                Separated link
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div className="flex flex-col gap-4">
                                    <a href="#" className="flex justify-between gap-6">
                                        <div className="flex items-center gap-4">
                                            <img src="./img/user-5.jpg" className="rounded-full h-10" alt="" />
                                            <div>
                                                <h5 className="text-gray-800 dark:text-white text-sm mb-1 total-revenue">
                                                    Chadengle</h5>
                                                <p className="text-xs text-gray-400">Hey! there I'm available...</p>
                                            </div>
                                        </div>
                                        <p className="text-xs text-gray-400">4:30 PM</p>
                                    </a>

                                    <div className="border-b dark:border-gray-700 border-gray-50"></div>

                                    <a href="#" className="flex justify-between gap-6">
                                        <div className="flex items-center gap-4">
                                            <img src="./img/user-2.jpg" className="rounded-full h-10" alt="user-1" />
                                            <div>
                                                <h5 className="text-gray-800 dark:text-white text-sm mb-1 total-revenue">
                                                    Tomaslau</h5>
                                                <p className="text-xs text-gray-400">I've finished it! See you so...</p>
                                            </div>
                                        </div>
                                        <p className="text-xs text-gray-400">10:15 PM</p>
                                    </a>

                                    <div className="border-b dark:border-gray-700 border-gray-50"></div>

                                    <a href="#" className="flex justify-between gap-6">
                                        <div className="flex items-center gap-4">
                                            <img src="./img/user-4.jpg" className="rounded-full h-10" alt="user-2" />
                                            <div>
                                                <h5 className="text-gray-800 dark:text-white text-sm mb-1 total-revenue">
                                                    Still david</h5>
                                                <p className="text-xs text-gray-400">This theme is awesome!</p>
                                            </div>
                                        </div>
                                        <p className="text-xs text-gray-400">1:30 PM</p>
                                    </a>

                                    <div className="border-b dark:border-gray-700 border-gray-50"></div>

                                    <a href="#" className="flex justify-between gap-6">
                                        <div className="flex items-center gap-4">
                                            <img src="./img/user-3.jpg" className="rounded-full h-10" alt="user-3" />
                                            <div>
                                                <h5 className="text-gray-800 dark:text-white text-sm mb-1 total-revenue">
                                                    Kurafire</h5>
                                                <p className="text-xs text-gray-400">Nice to meet you</p>
                                            </div>
                                        </div>
                                        <p className="text-xs text-gray-400">14:20 PM</p>
                                    </a>

                                    <div className="border-b dark:border-gray-700 border-gray-50"></div>

                                    <a href="#" className="flex justify-between gap-6">
                                        <div className="flex items-center gap-4">
                                            <img src="./img/user-2.jpg" className="rounded-full h-10" alt="user-2" />
                                            <div>
                                                <h5 className="text-gray-800 dark:text-white text-sm mb-1 total-revenue">
                                                    Shahedk</h5>
                                                <p className="text-xs text-gray-400">Hey! there I'm available...</p>
                                            </div>
                                        </div>
                                        <p className="text-xs text-gray-400">2:36 AM</p>
                                    </a>
                                </div>

                            </div>
                        </div>
                        {/* <!-- card-end --> */}

                        <div className="xl:col-span-2 col-span-1 scrollable   overflow-scroll">
                            <div className="card">
                                <div className="p-3 bg-white w-full total-revenue rounded">

                                    <div className="flex items-center justify-between mb-6">
                                        <h3 className="card-title">Latest Projects</h3>

                                        <div>
                                            <button data-fc-target="dropdown-target6" data-fc-type="dropdown"
                                                type="button" data-fc-placement="bottom-end" className="fc-dropdown">
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </button>

                                            <div id="dropdown-target6"
                                                className="hidden bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                    href="javascript:void(0)">
                                                    Action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Another action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Something else
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Separated link
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="overflow-x-auto  main-content-scroll">
                                        <div className="min-w-full inline-block align-middle">
                                            <div className="overflow-hidden">
                                                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                                    <thead>
                                                        <tr className="border-b-2 dark:border-gray-700">
                                                            <th scope="col"
                                                                className="px-4 py-4 text-start font-semibold text-gray-500 dark:text-gray-200">
                                                                #</th>
                                                            <th scope="col"
                                                                className="px-4 py-4 text-start font-semibold text-gray-500 dark:text-gray-200">
                                                                Project Name</th>
                                                            <th scope="col"
                                                                className="px-4 py-4 text-start font-semibold text-gray-500 dark:text-gray-200">
                                                                Start Date</th>
                                                            <th scope="col"
                                                                className="px-4 py-4 text-start font-semibold text-gray-500 dark:text-gray-200">
                                                                Due Date</th>
                                                            <th scope="col"
                                                                className="px-4 py-4 text-start font-semibold text-gray-500 dark:text-gray-200">
                                                                Status</th>
                                                            <th scope="col"
                                                                className="px-4 py-4 text-start font-semibold text-gray-500 dark:text-gray-200">
                                                                Assign</th>
                                                        </tr>
                                                    </thead>

                                                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                                                        <tr
                                                            className="project-first transition-all  hover:bg-gray-50 dark:hover:bg-gray-700/40">
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                1</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                Admin v1</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                01/01/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                26/04/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                <span
                                                                    className="text-xs text-white bg-blue-500 rounded-md px-1 py-0.5">Released</span>
                                                            </td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Coderthemes</td>
                                                        </tr>

                                                        <tr
                                                            className="project-first transition-all hover:bg-gray-50 dark:hover:bg-gray-700/40">
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                2</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                Frontend v1</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                01/01/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                26/04/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                <span
                                                                    className="text-xs text-white bg-pink-500 rounded-md px-1 py-0.5">Released</span>
                                                            </td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                admin</td>
                                                        </tr>

                                                        <tr
                                                            className="project-first transition-all hover:bg-gray-50 dark:hover:bg-gray-700/40">
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                3</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                Admin v1.1</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                01/05/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                10/05/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                <span
                                                                    className="text-xs text-white bg-yellow-500 rounded-md px-1 py-0.5">Pending</span>
                                                            </td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Coderthemes</td>
                                                        </tr>

                                                        <tr
                                                            className="project-first transition-all hover:bg-gray-50 dark:hover:bg-gray-700/40">
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                4</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                Frontend v1.1</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                01/01/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                31/05/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                <span
                                                                    className="text-xs text-white bg-pink-500 rounded-md px-1 py-0.5">Work
                                                                    in
                                                                    Progress</span>
                                                            </td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                admin</td>
                                                        </tr>

                                                        <tr
                                                            className="project-first transition-all hover:bg-gray-50 dark:hover:bg-gray-700/40">
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                5</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                Admin v1.3</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                01/01/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                31/05/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                <span
                                                                    className="text-xs text-white bg-orange-500 rounded-md px-1 py-0.5">Coming
                                                                    soon</span>
                                                            </td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Coderthemes</td>
                                                        </tr>

                                                        <tr
                                                            className="project-first transition-all hover:bg-gray-50 dark:hover:bg-gray-700/40">
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                6</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                Admin v1.3</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                01/01/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                31/05/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                <span
                                                                    className="text-xs text-white bg-red-500 rounded-md px-1 py-0.5">Coming
                                                                    soon</span>
                                                            </td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto admin</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* <!-- card-end --> */}
                    </div>
                </section>

                {/* <!-- seshboard inbox end--> */}



                {/* <!-- Footer start --> */}

                <footer className="footer card rounded-none mt-auto bg-white total-revenue">
                    <div className="h-16 flex items-center px-8 rounded-none">
                        <div className="flex md:justify-between justify-center w-full gap-4">
                            <div>
                                <script>document.write(new Date().getFullYear())</script> © Adminto - <a
                                    href="https://coderthemes.com/" target="_blank">Coderthemes</a>
                            </div>
                            <div className="md:flex hidden gap-4 item-center md:justify-end">
                                <a href="javascript: void(0);"
                                    className="text-sm leading-5 text-zinc-600 transition hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white">About</a>
                                <a href="javascript: void(0);"
                                    className="text-sm leading-5 text-zinc-600 transition hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white">Help</a>
                                <a href="javascript: void(0);"
                                    className="text-sm leading-5 text-zinc-600 transition hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white">Contact
                                    Us</a>
                            </div>
                        </div>
                    </div>
                </footer>

                {/* <!-- Footer end -->/ */}

            </div>


            {/* </div> */}
        </>
    );
}

export default HomePage;