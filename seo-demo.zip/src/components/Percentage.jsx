import React from 'react';
import PercentageCircle from './PercentageCircle';

const Percentage = () => {
  return (
    <div>
      <PercentageCircle percent={15} />
    </div>
  );
};

export default Percentage;