import React from "react";

import userS from '../img/user-11.jpg';
import userT from '../img/user-2.jpg';
import userF from '../img/user-3.jpg';
import userFive from '../img/user-5.jpg';
import NavArea from '../components/NavArea'

function Topbar() {

    const dynamicPercent = 150;
    const dynamicPercentLess = 182;

    return (

        <>
            {/* <div className="page-content-all-area"> */}
            <div className="page-content   ">
                <NavArea />
            </div>
            {/* <!====================Topbar End ==========================> */}

            {/* <!========== Main Content Total Revenue card start =======> */}

            <div className="text-gray-600  app-header">
                <div className="container px-7 py-2 mx-auto ">
                    <div className="flex flex-wrap -m-4">
                        <div className="lg:w-1/4 md:w-1/2 p-3 w-full">
                            <a className="block relative rounded overflow-hidden">
                                {/* <!-- <img alt="ecommerce"  className="object-cover object-center w-full h-full block" src="https://dummyimage.com/420x260"> --> */}

                                <div className="p-6 bg-white h-44 total-revenue rounded">
                                    <div className="flex items-center justify-between ">
                                        <h4 className="card-title">Total Revenue</h4>

                                        <div className="z-10">
                                            <button className="dropdown-revenue-cl " type="button">
                                                {/* <!-- <i  className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </button>

                                            <div id="dropdown-revenue"
                                                className="hidden fc-dropdown bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                    href="javascript:void(0)">
                                                    Action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Another action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Something else
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Separated link
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    {/* strokeDasharray: `percent={dynamicPercent}, 75`, */}
                                    <div className="flex items-center justify-between">
                                        <div dir="ltr" className="card">
                                            <div className="percent">
                                                <svg>
                                                    <circle cx="105" cy="105" r="30"></circle>
                                                    <circle cx="105" cy="105" r="30" style={{
                                                        strokeDasharray: `${dynamicPercent}, 100`,
                                                        strokeDashoffset: '25',
                                                        stroke: 'red-rgba',
                                                        fill: 'none',  // Change the stroke color as needed
                                                    }}></circle>
                                                </svg>
                                                <div className="number ">
                                                    <h3 className="text-red-rgba">58<span>%</span></h3>
                                                </div>
                                            </div>

                                            <div className="text-end progress-text">
                                                <h2
                                                    className="total-revenue revenue-nub text-3xl font-normal text-gray-800 dark:text-white mb-1">
                                                    256
                                                </h2>
                                                <p className="text-gray-400 font-normal">Revenue today</p>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </a>
                        </div>


                        <div className="lg:w-1/4 md:w-1/2 p-3 w-full">
                            <a className="block relative rounded overflow-hidden">
                                <div className="p-6 bg-white h-44 total-revenue rounded">
                                    <div className="flex items-center justify-between pb-6">
                                        <h4 className="card-title">Sales Analytics</h4>

                                        <div className="z-10">
                                            <button className="dropdown-revenue-cl " type="button">
                                                {/* <!-- <i  className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </button>

                                            <div id="dropdown-target1"
                                                className="hidden bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                    href="javascript:void(0)">
                                                    Action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Another action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Something else
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Separated link
                                                </a>
                                            </div>
                                        </div>
                                    </div>


                                    <div className="flex items-center justify-between ">
                                        <div dir="ltr" className="card w-full h-2">
                                            <div className="flex justify-around gap-x-6 pb-2">

                                                <div
                                                    className="bg-green-500 m-auto h-5 w-16 text-white rounded-full text-xs px-2 py-0.5">
                                                    32%
                                                    {/* <!-- <i  className="mdi mdi-trending-up"></i> --> */}
                                                    <i className="fa-solid fa-arrow-trend-up"></i>
                                                </div>
                                                <div className="text-end ">
                                                    <h2
                                                        className="total-revenue revenue-nub text-3xl font-normal text-gray-800 dark:text-white mb-1">
                                                        4569
                                                    </h2>
                                                    <p className="text-gray-400 font-normal">Revenue today</p>
                                                </div>
                                            </div>
                                            <div
                                                className="w-full bg-gray-200 rounded-full h-2.5 mb-4 dark:bg-gray-700">
                                                <div className="bg-green-500 h-2.5 rounded-full w-3/4">
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>


                        <div className="lg:w-1/4 md:w-1/2 p-3 w-full">
                            <a className="block relative rounded overflow-hidden">
                                {/* <!-- <img alt="ecommerce"  className="object-cover object-center w-full h-full block" src="https://dummyimage.com/420x260"> --> */}

                                <div className="p-6 bg-white h-44 total-revenue rounded">
                                    <div className="flex items-center justify-between ">
                                        <h4 className="card-title">Statistics</h4>

                                        <div className="z-10">
                                            <button className="dropdown-revenue-cl " type="button">
                                                {/* <!-- <i  className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </button>

                                            <div id="dropdown-revenue"
                                                className="hidden fc-dropdown bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                    href="javascript:void(0)">
                                                    Action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Another action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Something else
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Separated link
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    {/* strokeDasharray: `percent={dynamicPercent}, 75`, */}
                                    <div className="flex items-center justify-between">
                                        <div dir="ltr" className="card">
                                            <div className="percent">
                                                <svg>
                                                    <circle cx="105" cy="105" r="30"></circle>
                                                    <circle cx="105" cy="105" r="30" style={{
                                                        strokeDasharray: `${dynamicPercentLess}, 100`,
                                                        strokeDashoffset: '25',
                                                        stroke: 'bg-yello-rgba',
                                                        fill: 'none',  // Change the stroke color as needed
                                                    }}></circle>
                                                </svg>
                                                <div className="number ">
                                                    <h3 className="text-red-rgba">88<span>%</span></h3>
                                                </div>
                                            </div>

                                            <div className="text-end progress-text">
                                                <h2
                                                    className="total-revenue revenue-nub text-3xl font-normal text-gray-800 dark:text-white mb-1">
                                                   4569
                                                </h2>
                                                <p className="text-gray-400 font-normal">Revenue today</p>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </a>
                        </div>
                        {/* </div> */}
                        {/* </div> */}
                        {/* </div> */}



                        <div className="lg:w-1/4 md:w-1/2 p-3 w-full">
                            <div className="block relative rounded overflow-hidden">
                                <div className="p-3 bg-white h-44 total-revenue rounded">
                                    <div className="flex items-center justify-between pb-6">
                                        <h4 className="card-title">Daily Sales</h4>

                                        <div className="z-10">
                                            <button d className="dropdown-revenue-cl " type="button">
                                                {/* <!-- <i  className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </button>

                                            <div id="dropdown-target1"
                                                className="hidden bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                    href="javascript:void(0)">
                                                    Action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Another action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Something else
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Separated link
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="flex items-center justify-between ">
                                        <div dir="ltr" className="card w-full h-2">
                                            <div className="flex justify-around gap-x-6 pb-2">

                                                <div
                                                    className="bg-[#ff8acc] m-auto h-5 w-16 text-white rounded-full text-xs px-2 py-0.5">
                                                    32%
                                                    {/* <!-- <i  className="mdi mdi-trending-up"></i> --> */}
                                                    <i className="fa-solid fa-arrow-trend-up"></i>
                                                </div>
                                                <div className="text-end ">
                                                    <h2
                                                        className="total-revenue revenue-nub text-3xl font-normal text-gray-800 dark:text-white mb-1">
                                                        159
                                                    </h2>
                                                    <p className="text-gray-400 font-normal">Revenue today</p>
                                                </div>
                                            </div>
                                            <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4 dark:bg-gray-700">
                                                <div className="bg-[#ff8acc] h-2.5 rounded-full w-3/4 " >
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>




                {/* <!-- deshboard chart area start --> */}
                {/* <!-- morris donut chart --> */}
                <section>

                    <div className="flex flex-wrap  w-full bg-[#f3f4f6]  app-header px-[0.8rem] py-2">
                        <div className="p-3 md:w-1/3 h-[450px]">
                            <div className="flex rounded-lg h-full bg-white p-6 flex-col total-revenue">
                                <div className="morris-area flex justify-between">
                                    <div className="morris-txt">
                                        <span>Daily Sales</span>

                                    </div>
                                    <div className="morris-icon">
                                        <div className="z-10">
                                            <button data-fc-target="dropdown-target1" data-fc-type="dropdown"
                                                type="button" data-fc-placement="bottom-end" className="fc-dropdown">
                                                {/* <!-- <i  className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </button>

                                            <div id="dropdown-target1"
                                                className="hidden bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                    href="javascript:void(0)">
                                                    Action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Another action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Something else
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Separated link
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                {/* <!-- <div  className="flex items-center mb-3"> --> */}

                                <div className="morris-donut relative top-[-25px]">
                                    <div id="donut-example" className="morris-donut-inverse"></div>
                                </div>





                                <div className="serieses text-center relative top-[-40px]">
                                    <div className="series-a">
                                        <span className="color-pink"></span>
                                        <span className="text-[#ff8acc]">Series A</span>
                                    </div>
                                    <div className="series-a">
                                        <span className="color-blue"></span>
                                        <span className="text-[#35b8e0]">Series B</span>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div className="p-3 md:w-1/3 h-[450px]">
                            <div className="flex rounded-lg h-full bg-white p-6 flex-col total-revenue">
                                {/* <!-- <div  className="flex items-center mb-3"> --> */}


                                <div className="morris-area flex justify-between">
                                    <div className="morris-txt">
                                        <span>Daily Sales</span>

                                    </div>
                                    <div className="morris-icon">
                                        <div className="z-10">
                                            <button data-fc-target="dropdown-target1" data-fc-type="dropdown"
                                                type="button" data-fc-placement="bottom-end" className="fc-dropdown mories">
                                                {/* <!-- <i  className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </button>

                                            <div id="dropdown-target1"
                                                className="hidden bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                    href="javascript:void(0)">
                                                    Action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Another action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Something else
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Separated link
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <canvas id="myChart" aria-label="chart" role="img" width="100" height="100">
                                    </canvas>
                                </div>




                                {/* <!-- </div> --> */}

                            </div>
                        </div>



                        <div className="p-3 md:w-1/3 h-[450px]">
                            <div className="flex rounded-lg h-full bg-white p-6 flex-col total-revenue">
                                {/* <!-- <div  className="flex items-center mb-3"> --> */}


                                <div className="morris-area flex justify-between">
                                    <div className="morris-txt">
                                        <span>Daily Sales</span>

                                    </div>
                                    <div className="morris-icon">
                                        <div className="z-10">
                                            <button data-fc-target="dropdown-target1" data-fc-type="dropdown"
                                                type="button" data-fc-placement="bottom-end"
                                                className="fc-dropdown ">
                                                {/* <!-- <i  className="mdi mdi-dots-vertical text-xl"></i> --> */}
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </button>

                                            <div id="dropdown-target1"
                                                className="hidden bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                    href="javascript:void(0)">
                                                    Action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Another action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Something else
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Separated link
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    {/* <!-- </div> --> */}
                                </div>

                                <div>
                                    <canvas id="lineChart" aria-label="chart" role="img" width="100" height="100">
                                    </canvas>
                                </div>
                            </div>


                        </div>
                    </div>

                </section>
                {/* <!-- </div> --> */}



                {/* <!-- maim content end --> */}


                {/* <!-- identity users card start --> */}


                <section className="text-gray-600 ">
                    <div className="p-4  mx-auto bg-[#f3f4f6] app-header px-7 py-2 ">
                        <div className="flex flex-wrap -m-4 text-center">
                            <div className="p-3 md:w-1/4 sm:w-1/2 w-full">
                                <div
                                    className="total-revenue py-8 px-8 max-w-sm mx-auto bg-white rounded shadow-lg space-y-2 sm:py-4 sm:flex sm:items-center sm:space-y-0 sm:space-x-6">
                                    <img className="block mx-auto w-1/3 rounded-full sm:mx-0 sm:shrink-0"
                                        src={userS} alt="Woman's Face" />
                                    <div className="text-center space-y-2 sm:text-left">
                                        <div className="space-y-0.5">
                                            <h5 className="text-gray-800 dark:text-white mb-1 total-revenue">
                                                Chadengle
                                            </h5>
                                            <p className="mb-2 text-gray-400 font-normal truncate">
                                                coderthemes@g
                                            </p>
                                        </div>
                                        <span
                                            className="px-4 py-1 text-sm text-yellow-600 font-semibold    focus:outline-none focus:ring-2 focus:ring-purple-600 focus:ring-offset-2">Admin</span>
                                    </div>
                                </div>
                            </div>
                            <div className="p-3 md:w-1/4 sm:w-1/2 w-full">
                                <div
                                    className="total-revenue py-8 px-8 max-w-sm mx-auto bg-white rounded shadow-lg space-y-2 sm:py-4 sm:flex sm:items-center sm:space-y-0 sm:space-x-6">
                                    <img className="block  mx-auto w-1/3 rounded-full sm:mx-0 sm:shrink-0"
                                        src={userT} alt="Woman's Face" />
                                    <div className="text-center space-y-2 sm:text-left">
                                        <div className="space-y-0.5">
                                            <h5 className="text-gray-800 dark:text-white mb-1 total-revenue">
                                                Chadengle
                                            </h5>
                                            <p className="mb-2 text-gray-400 font-normal truncate">
                                                coderthemes@g
                                            </p>
                                        </div>
                                        <span
                                            className="px-4 py-1 text-sm text-pink-500 font-semibold    focus:outline-none focus:ring-2 focus:ring-purple-600 focus:ring-offset-2">Admin</span>
                                    </div>
                                </div>
                            </div>



                            <div className="p-3 md:w-1/4 sm:w-1/2 w-full">
                                <div
                                    className="total-revenue py-8 px-8 max-w-sm mx-auto bg-white rounded shadow-lg space-y-2 sm:py-4 sm:flex sm:items-center sm:space-y-0 sm:space-x-6">
                                    <img className="block mx-auto w-1/3 rounded-full sm:mx-0 sm:shrink-0"
                                        src={userF} alt="Woman's Face" />
                                    <div className="text-center space-y-2 sm:text-left">
                                        <div className="space-y-0.5">
                                            <h5 className="text-gray-800 dark:text-white mb-1 total-revenue">
                                                Chadengle
                                            </h5>
                                            <p className="mb-2 text-gray-400 font-normal truncate">
                                                Developer
                                            </p>
                                        </div>
                                        <span
                                            className="px-4 py-1 text-sm text-green-500 font-semibold    focus:outline-none focus:ring-2 focus:ring-purple-600 focus:ring-offset-2">Admin</span>
                                    </div>
                                </div>
                            </div>



                            <div className="p-3 md:w-1/4 sm:w-1/2 w-full">
                                <div
                                    className="total-revenue py-8 px-8 max-w-sm mx-auto bg-white rounded shadow-lg space-y-2 sm:py-4 sm:flex sm:items-center sm:space-y-0 sm:space-x-6">
                                    <img className="block mx-auto w-1/3 rounded-full sm:mx-0 sm:shrink-0"
                                        src={userS} alt="Woman's Face" />
                                    <div className="text-center space-y-2 sm:text-left">
                                        <div className="space-y-0.5">
                                            <h5 className="text-gray-800 dark:text-white mb-1 total-revenue">
                                                Chadengle


                                            </h5>
                                            <p className="mb-2 text-gray-400 font-normal truncate">
                                                coderthemes@g
                                            </p>
                                        </div>
                                        <span
                                            className="px-4 py-1 text-sm text-blue-400 font-semibold    focus:outline-none focus:ring-2 focus:ring-purple-600 focus:ring-offset-2">Developer</span>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>

                {/* <!-- identity card end --> */}

                {/* <!-- seshboard inbox start--> */}
                <section>
                    <div className="p-4 xl:grid-cols-3 grid-cols-1 gap-6 flex bg-[#f3f4f6] app-header px-[1.5rem] py-4">
                        <div className="card">
                            <div className="p-6 bg-white total-revenue rounded">

                                <div className="flex items-center justify-between mb-6">
                                    <h4 className="card-title">Inbox</h4>

                                    <div>
                                        <button data-fc-target="dropdown-target5" data-fc-type="dropdown" type="button"
                                            data-fc-placement="bottom-end" className="fc-dropdown">
                                            <i className="fa-solid fa-ellipsis-vertical"></i>
                                        </button>

                                        <div id=" dropdown-target5"
                                            className=" left-1/2 top-80 absolute left-439.5 top-921 bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown hidden"
                                        >
                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                href="javascript:void(0)">
                                                Action
                                            </a>
                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                href="javascript:void(0)">
                                                Another action
                                            </a>
                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                href="javascript:void(0)">
                                                Something else
                                            </a>
                                            <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                href="javascript:void(0)">
                                                Separated link
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div className="flex flex-col gap-4">
                                    <a href="#" className="flex justify-between gap-6">
                                        <div className="flex items-center gap-4">
                                            <img src={userFive} className="rounded-full h-10" alt="" />
                                            <div>
                                                <h5 className="text-gray-800 dark:text-white text-sm mb-1 total-revenue">
                                                    Chadengle</h5>
                                                <p className="text-xs text-gray-400">Hey! there I'm available...</p>
                                            </div>
                                        </div>
                                        <p className="text-xs text-gray-400">4:30 PM</p>
                                    </a>

                                    <div className="border-b dark:border-gray-700 border-gray-50"></div>

                                    <a href="#" className="flex justify-between gap-6">
                                        <div className="flex items-center gap-4">
                                            <img src={userT} className="rounded-full h-10" alt="user-1" />
                                            <div>
                                                <h5 className="text-gray-800 dark:text-white text-sm mb-1 total-revenue">
                                                    Tomaslau</h5>
                                                <p className="text-xs text-gray-400">I've finished it! See you so...</p>
                                            </div>
                                        </div>
                                        <p className="text-xs text-gray-400">10:15 PM</p>
                                    </a>

                                    <div className="border-b dark:border-gray-700 border-gray-50"></div>

                                    <a href="#" className="flex justify-between gap-6">
                                        <div className="flex items-center gap-4">
                                            <img src={userF} className="rounded-full h-10" alt="user-2" />
                                            <div>
                                                <h5 className="text-gray-800 dark:text-white text-sm mb-1 total-revenue">
                                                    Still david</h5>
                                                <p className="text-xs text-gray-400">This theme is awesome!</p>
                                            </div>
                                        </div>
                                        <p className="text-xs text-gray-400">1:30 PM</p>
                                    </a>

                                    <div className="border-b dark:border-gray-700 border-gray-50"></div>

                                    <a href="#" className="flex justify-between gap-6">
                                        <div className="flex items-center gap-4">
                                            <img src={userF} className="rounded-full h-10" alt="user-3" />
                                            <div>
                                                <h5 className="text-gray-800 dark:text-white text-sm mb-1 total-revenue">
                                                    Kurafire</h5>
                                                <p className="text-xs text-gray-400">Nice to meet you</p>
                                            </div>
                                        </div>
                                        <p className="text-xs text-gray-400">14:20 PM</p>
                                    </a>

                                    <div className="border-b dark:border-gray-700 border-gray-50"></div>

                                    <a href="#" className="flex justify-between gap-6">
                                        <div className="flex items-center gap-4">
                                            <img src={userT} className="rounded-full h-10" alt="user-2" />
                                            <div>
                                                <h5 className="text-gray-800 dark:text-white text-sm mb-1 total-revenue">
                                                    Shahedk</h5>
                                                <p className="text-xs text-gray-400">Hey! there I'm available...</p>
                                            </div>
                                        </div>
                                        <p className="text-xs text-gray-400">2:36 AM</p>
                                    </a>
                                </div>

                            </div>
                        </div>
                        {/* <!-- card-end --> */}

                        <div className="xl:col-span-2 col-span-1 scrollable   overflow-scroll">
                            <div className="card">
                                <div className="p-3 bg-white w-full total-revenue rounded">

                                    <div className="flex items-center justify-between mb-6">
                                        <h3 className="card-title">Latest Projects</h3>

                                        <div>
                                            <button data-fc-target="dropdown-target6" data-fc-type="dropdown"
                                                type="button" data-fc-placement="bottom-end" className="fc-dropdown">
                                                <i className="fa-solid fa-ellipsis-vertical"></i>
                                            </button>

                                            <div id="dropdown-target6"
                                                className="hidden bg-white shadow rounded border dark:border-slate-700 fc-dropdown-open:translate-y-0 translate-y-3 origin-center transition-all duration-300 py-2 dark:bg-gray-800 fc-dropdown">
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-stone-100 dark:hover:bg-slate-700 dark:hover:text-gray-200"
                                                    href="javascript:void(0)">
                                                    Action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Another action
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Something else
                                                </a>
                                                <a className="flex items-center py-1.5 px-5 text-sm transition-all duration-300 bg-transparent text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300"
                                                    href="javascript:void(0)">
                                                    Separated link
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="overflow-x-auto  main-content-scroll">
                                        <div className="min-w-full inline-block align-middle">
                                            <div className="overflow-hidden">
                                                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                                    <thead>
                                                        <tr className="border-b-2 dark:border-gray-700">
                                                            <th scope="col"
                                                                className="px-4 py-4 text-start font-semibold text-gray-500 dark:text-gray-200">
                                                                #</th>
                                                            <th scope="col"
                                                                className="px-4 py-4 text-start font-semibold text-gray-500 dark:text-gray-200">
                                                                Project Name</th>
                                                            <th scope="col"
                                                                className="px-4 py-4 text-start font-semibold text-gray-500 dark:text-gray-200">
                                                                Start Date</th>
                                                            <th scope="col"
                                                                className="px-4 py-4 text-start font-semibold text-gray-500 dark:text-gray-200">
                                                                Due Date</th>
                                                            <th scope="col"
                                                                className="px-4 py-4 text-start font-semibold text-gray-500 dark:text-gray-200">
                                                                Status</th>
                                                            <th scope="col"
                                                                className="px-4 py-4 text-start font-semibold text-gray-500 dark:text-gray-200">
                                                                Assign</th>
                                                        </tr>
                                                    </thead>

                                                    <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                                                        <tr
                                                            className="project-first transition-all  hover:bg-gray-50 dark:hover:bg-gray-700/40">
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                1</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                Admin v1</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                01/01/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                26/04/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                <span
                                                                    className="text-xs text-white bg-blue-500 rounded-md px-1 py-0.5">Released</span>
                                                            </td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Coderthemes</td>
                                                        </tr>

                                                        <tr
                                                            className="project-first transition-all hover:bg-gray-50 dark:hover:bg-gray-700/40">
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                2</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                Frontend v1</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                01/01/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                26/04/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                <span
                                                                    className="text-xs text-white bg-pink-500 rounded-md px-1 py-0.5">Released</span>
                                                            </td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                admin</td>
                                                        </tr>

                                                        <tr
                                                            className="project-first transition-all hover:bg-gray-50 dark:hover:bg-gray-700/40">
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                3</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                Admin v1.1</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                01/05/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                10/05/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                <span
                                                                    className="text-xs text-white bg-yellow-500 rounded-md px-1 py-0.5">Pending</span>
                                                            </td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Coderthemes</td>
                                                        </tr>

                                                        <tr
                                                            className="project-first transition-all hover:bg-gray-50 dark:hover:bg-gray-700/40">
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                4</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                Frontend v1.1</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                01/01/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                31/05/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                <span
                                                                    className="text-xs text-white bg-pink-500 rounded-md px-1 py-0.5">Work
                                                                    in
                                                                    Progress</span>
                                                            </td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                admin</td>
                                                        </tr>

                                                        <tr
                                                            className="project-first transition-all hover:bg-gray-50 dark:hover:bg-gray-700/40">
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                5</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                Admin v1.3</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                01/01/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                31/05/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                <span
                                                                    className="text-xs text-white bg-orange-500 rounded-md px-1 py-0.5">Coming
                                                                    soon</span>
                                                            </td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Coderthemes</td>
                                                        </tr>

                                                        <tr
                                                            className="project-first transition-all hover:bg-gray-50 dark:hover:bg-gray-700/40">
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                6</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto
                                                                Admin v1.3</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                01/01/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                31/05/2017</td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                <span
                                                                    className="text-xs text-white bg-red-500 rounded-md px-1 py-0.5">Coming
                                                                    soon</span>
                                                            </td>
                                                            <td
                                                                className="px-4 py-4 whitespace-nowrap text-gray-500 dark:text-gray-400">
                                                                Adminto admin</td>
                                                        </tr>
                                                    </tbody>

                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        {/* <!-- card-end --> */}
                    </div>
                </section>
            </div>

            {/* <!-- seshboard inbox end--> */}

        </>
    )
}
export default Topbar;